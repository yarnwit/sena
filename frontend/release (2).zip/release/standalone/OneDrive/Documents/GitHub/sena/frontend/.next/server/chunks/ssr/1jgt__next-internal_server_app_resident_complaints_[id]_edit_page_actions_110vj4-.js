module.exports=[55536,(a,b,c)=>{}];

//# sourceMappingURL=1jgt__next-internal_server_app_resident_complaints_%5Bid%5D_edit_page_actions_110vj4-.js.map