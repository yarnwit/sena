module.exports=[68787,(a,b,c)=>{}];

//# sourceMappingURL=0qom_sena_frontend__next-internal_server_app_admin_meetings_page_actions_0haedun.js.map