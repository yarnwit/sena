module.exports=[44003,(a,b,c)=>{}];

//# sourceMappingURL=1jgt__next-internal_server_app_staff_complaints_%5Bid%5D_edit_page_actions_1960upe.js.map