module.exports=[47485,(a,b,c)=>{}];

//# sourceMappingURL=0qom_sena_frontend__next-internal_server_app_staff_pending_page_actions_076g46p.js.map