module.exports=[50829,(a,b,c)=>{}];

//# sourceMappingURL=049c_frontend__next-internal_server_app_staff_complaints_%5Bid%5D_page_actions_12k5a7s.js.map