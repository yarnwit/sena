module.exports=[44820,(a,b,c)=>{}];

//# sourceMappingURL=0qom_sena_frontend__next-internal_server_app_admin_pending_page_actions_1mm3xc8.js.map