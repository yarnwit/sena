module.exports=[71940,(a,b,c)=>{}];

//# sourceMappingURL=0qom_sena_frontend__next-internal_server_app_staff_reports_page_actions_1to8amo.js.map