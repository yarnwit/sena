module.exports=[2237,(e,o,d)=>{}];

//# sourceMappingURL=0qom_sena_frontend__next-internal_server_app_favicon_ico_route_actions_0n8cr9_.js.map