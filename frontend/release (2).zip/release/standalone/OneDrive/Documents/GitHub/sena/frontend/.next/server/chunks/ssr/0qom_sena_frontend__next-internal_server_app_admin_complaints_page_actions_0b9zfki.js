module.exports=[66852,(a,b,c)=>{}];

//# sourceMappingURL=0qom_sena_frontend__next-internal_server_app_admin_complaints_page_actions_0b9zfki.js.map