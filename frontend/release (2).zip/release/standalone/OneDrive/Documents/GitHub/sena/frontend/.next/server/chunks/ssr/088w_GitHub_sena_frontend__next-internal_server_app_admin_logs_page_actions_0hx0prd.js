module.exports=[72750,(a,b,c)=>{}];

//# sourceMappingURL=088w_GitHub_sena_frontend__next-internal_server_app_admin_logs_page_actions_0hx0prd.js.map