module.exports=[88790,(a,b,c)=>{}];

//# sourceMappingURL=0qom_sena_frontend__next-internal_server_app_staff_dashboard_page_actions_0bdeeeb.js.map