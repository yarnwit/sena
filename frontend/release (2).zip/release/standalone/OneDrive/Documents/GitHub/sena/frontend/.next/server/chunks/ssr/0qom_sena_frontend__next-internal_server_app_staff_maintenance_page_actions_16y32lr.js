module.exports=[34514,(a,b,c)=>{}];

//# sourceMappingURL=0qom_sena_frontend__next-internal_server_app_staff_maintenance_page_actions_16y32lr.js.map