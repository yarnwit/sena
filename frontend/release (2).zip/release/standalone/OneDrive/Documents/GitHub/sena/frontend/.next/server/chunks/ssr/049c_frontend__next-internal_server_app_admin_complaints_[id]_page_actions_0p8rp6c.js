module.exports=[32209,(a,b,c)=>{}];

//# sourceMappingURL=049c_frontend__next-internal_server_app_admin_complaints_%5Bid%5D_page_actions_0p8rp6c.js.map