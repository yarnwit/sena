module.exports=[24594,(a,b,c)=>{}];

//# sourceMappingURL=0qom_sena_frontend__next-internal_server_app_%28auth%29_register_page_actions_1-miquf.js.map