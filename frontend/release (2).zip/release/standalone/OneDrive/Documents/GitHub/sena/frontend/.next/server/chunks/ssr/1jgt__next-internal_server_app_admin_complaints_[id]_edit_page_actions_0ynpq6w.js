module.exports=[24888,(a,b,c)=>{}];

//# sourceMappingURL=1jgt__next-internal_server_app_admin_complaints_%5Bid%5D_edit_page_actions_0ynpq6w.js.map