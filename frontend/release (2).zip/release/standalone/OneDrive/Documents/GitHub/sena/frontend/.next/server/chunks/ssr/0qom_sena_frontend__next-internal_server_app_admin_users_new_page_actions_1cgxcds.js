module.exports=[95866,(a,b,c)=>{}];

//# sourceMappingURL=0qom_sena_frontend__next-internal_server_app_admin_users_new_page_actions_1cgxcds.js.map