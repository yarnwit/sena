module.exports=[93175,(a,b,c)=>{}];

//# sourceMappingURL=1jgt__next-internal_server_app_resident_complaints_%5Bid%5D_page_actions_1w69g5p.js.map