module.exports=[28770,(a,b,c)=>{}];

//# sourceMappingURL=0qom_sena_frontend__next-internal_server_app_admin_profile_page_actions_07c57nj.js.map