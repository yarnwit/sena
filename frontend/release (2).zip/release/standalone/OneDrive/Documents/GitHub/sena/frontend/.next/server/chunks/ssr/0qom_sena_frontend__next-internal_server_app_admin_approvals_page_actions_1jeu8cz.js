module.exports=[51296,(a,b,c)=>{}];

//# sourceMappingURL=0qom_sena_frontend__next-internal_server_app_admin_approvals_page_actions_1jeu8cz.js.map