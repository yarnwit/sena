module.exports=[97276,(a,b,c)=>{}];

//# sourceMappingURL=0qom_sena_frontend__next-internal_server_app_staff_complaints_page_actions_0mvvqo2.js.map