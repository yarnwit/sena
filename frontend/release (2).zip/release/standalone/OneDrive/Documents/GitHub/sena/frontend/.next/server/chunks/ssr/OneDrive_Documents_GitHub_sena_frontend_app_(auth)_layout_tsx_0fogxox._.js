module.exports=[39871,a=>{"use strict";var b=a.i(46610);a.s(["default",0,function({children:a}){return(0,b.jsx)(b.Fragment,{children:a})}])}];

//# sourceMappingURL=OneDrive_Documents_GitHub_sena_frontend_app_%28auth%29_layout_tsx_0fogxox._.js.map