1:"$Sreact.fragment"
3:I[8518,["/_next/static/chunks/2fm3gk9ef_80x.js","/_next/static/chunks/3ygafntudsnbf.js","/_next/static/chunks/3bc93-2j7_8qn.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":["$L2",null,["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"KCzaLniJnB27GQ7E-pt5j"}
5:null
2:E{"digest":"NEXT_REDIRECT;replace;/login;307;"}
