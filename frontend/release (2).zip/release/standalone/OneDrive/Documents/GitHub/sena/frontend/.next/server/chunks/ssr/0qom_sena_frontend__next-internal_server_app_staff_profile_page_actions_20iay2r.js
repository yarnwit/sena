module.exports=[98758,(a,b,c)=>{}];

//# sourceMappingURL=0qom_sena_frontend__next-internal_server_app_staff_profile_page_actions_20iay2r.js.map