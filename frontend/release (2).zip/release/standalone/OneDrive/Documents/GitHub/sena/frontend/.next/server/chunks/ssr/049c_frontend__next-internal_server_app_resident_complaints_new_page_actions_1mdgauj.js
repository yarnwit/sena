module.exports=[24924,(a,b,c)=>{}];

//# sourceMappingURL=049c_frontend__next-internal_server_app_resident_complaints_new_page_actions_1mdgauj.js.map