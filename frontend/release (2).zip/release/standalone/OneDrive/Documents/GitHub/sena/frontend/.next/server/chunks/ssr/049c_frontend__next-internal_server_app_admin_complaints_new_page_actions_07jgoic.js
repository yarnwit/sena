module.exports=[52344,(a,b,c)=>{}];

//# sourceMappingURL=049c_frontend__next-internal_server_app_admin_complaints_new_page_actions_07jgoic.js.map