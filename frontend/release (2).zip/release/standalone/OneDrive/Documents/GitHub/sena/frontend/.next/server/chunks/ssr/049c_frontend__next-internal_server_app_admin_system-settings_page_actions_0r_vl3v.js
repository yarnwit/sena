module.exports=[83328,(a,b,c)=>{}];

//# sourceMappingURL=049c_frontend__next-internal_server_app_admin_system-settings_page_actions_0r_vl3v.js.map