module.exports=[10368,(a,b,c)=>{}];

//# sourceMappingURL=0qom_sena_frontend__next-internal_server_app_admin_dashboard_page_actions_0k09qym.js.map