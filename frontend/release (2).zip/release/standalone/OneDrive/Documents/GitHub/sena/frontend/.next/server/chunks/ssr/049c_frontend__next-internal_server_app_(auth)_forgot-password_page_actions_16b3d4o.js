module.exports=[53899,(a,b,c)=>{}];

//# sourceMappingURL=049c_frontend__next-internal_server_app_%28auth%29_forgot-password_page_actions_16b3d4o.js.map