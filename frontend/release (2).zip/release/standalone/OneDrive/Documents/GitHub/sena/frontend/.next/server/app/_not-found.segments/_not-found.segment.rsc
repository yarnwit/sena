1:"$Sreact.fragment"
2:I[72319,["/_next/static/chunks/2fm3gk9ef_80x.js","/_next/static/chunks/3ygafntudsnbf.js","/_next/static/chunks/3bc93-2j7_8qn.js"],"default"]
3:I[61020,["/_next/static/chunks/2fm3gk9ef_80x.js","/_next/static/chunks/3ygafntudsnbf.js","/_next/static/chunks/3bc93-2j7_8qn.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"KCzaLniJnB27GQ7E-pt5j"}
