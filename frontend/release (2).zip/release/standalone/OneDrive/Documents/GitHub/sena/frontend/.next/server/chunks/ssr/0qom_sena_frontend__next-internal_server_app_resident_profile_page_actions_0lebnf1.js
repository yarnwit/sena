module.exports=[91737,(a,b,c)=>{}];

//# sourceMappingURL=0qom_sena_frontend__next-internal_server_app_resident_profile_page_actions_0lebnf1.js.map