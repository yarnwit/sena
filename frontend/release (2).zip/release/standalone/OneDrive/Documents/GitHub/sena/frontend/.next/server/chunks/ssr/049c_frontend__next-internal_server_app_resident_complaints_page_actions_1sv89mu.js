module.exports=[50281,(a,b,c)=>{}];

//# sourceMappingURL=049c_frontend__next-internal_server_app_resident_complaints_page_actions_1sv89mu.js.map