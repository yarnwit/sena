module.exports=[60517,(a,b,c)=>{}];

//# sourceMappingURL=0qom_sena_frontend__next-internal_server_app_resident_dashboard_page_actions_0wviyzd.js.map