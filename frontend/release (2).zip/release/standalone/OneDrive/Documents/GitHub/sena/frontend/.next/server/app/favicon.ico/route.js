var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_0iuj5m_._.js")
R.c("server/chunks/[root-of-the-server]__0kn8lzc._.js")
R.c("server/chunks/0qom_sena_frontend__next-internal_server_app_favicon_ico_route_actions_0n8cr9_.js")
R.m(30936)
module.exports=R.m(30936).exports
