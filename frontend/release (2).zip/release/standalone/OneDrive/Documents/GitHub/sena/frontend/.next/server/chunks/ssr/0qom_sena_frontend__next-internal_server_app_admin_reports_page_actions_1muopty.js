module.exports=[28900,(a,b,c)=>{}];

//# sourceMappingURL=0qom_sena_frontend__next-internal_server_app_admin_reports_page_actions_1muopty.js.map