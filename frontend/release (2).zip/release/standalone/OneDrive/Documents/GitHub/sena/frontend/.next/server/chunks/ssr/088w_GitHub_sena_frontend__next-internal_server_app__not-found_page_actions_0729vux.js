module.exports=[43324,(a,b,c)=>{}];

//# sourceMappingURL=088w_GitHub_sena_frontend__next-internal_server_app__not-found_page_actions_0729vux.js.map