module.exports=[57397,(a,b,c)=>{}];

//# sourceMappingURL=088w_GitHub_sena_frontend__next-internal_server_app_admin_users_page_actions_0ckjqzw.js.map