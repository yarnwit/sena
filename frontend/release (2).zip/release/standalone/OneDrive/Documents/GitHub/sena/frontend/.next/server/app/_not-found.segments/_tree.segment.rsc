:HL["/_next/static/chunks/233p45nuh4m5b.css","style"]
:HL["/_next/static/chunks/266vbhn0mypl9.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"/_not-found","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}},"staleTime":300,"buildId":"KCzaLniJnB27GQ7E-pt5j"}
