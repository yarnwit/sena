module.exports=[58663,(a,b,c)=>{}];

//# sourceMappingURL=0qom_sena_frontend__next-internal_server_app__global-error_page_actions_1vv7meg.js.map