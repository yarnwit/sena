module.exports=[26103,(a,b,c)=>{}];

//# sourceMappingURL=05v8_Documents_GitHub_sena_frontend__next-internal_server_app_page_actions_0riyavd.js.map