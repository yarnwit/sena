module.exports=[60904,(a,b,c)=>{}];

//# sourceMappingURL=0qom_sena_frontend__next-internal_server_app_staff_meetings_page_actions_1180csg.js.map