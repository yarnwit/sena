module.exports=[82775,(a,b,c)=>{}];

//# sourceMappingURL=049c_frontend__next-internal_server_app_staff_complaints_new_page_actions_1lpw4xr.js.map