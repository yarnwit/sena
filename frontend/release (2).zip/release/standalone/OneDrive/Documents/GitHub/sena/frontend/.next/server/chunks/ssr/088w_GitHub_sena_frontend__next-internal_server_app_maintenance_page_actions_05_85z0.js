module.exports=[65716,(a,b,c)=>{}];

//# sourceMappingURL=088w_GitHub_sena_frontend__next-internal_server_app_maintenance_page_actions_05_85z0.js.map