module.exports=[58387,(a,b,c)=>{}];

//# sourceMappingURL=0qom_sena_frontend__next-internal_server_app_staff_approvals_page_actions_08w09_r.js.map