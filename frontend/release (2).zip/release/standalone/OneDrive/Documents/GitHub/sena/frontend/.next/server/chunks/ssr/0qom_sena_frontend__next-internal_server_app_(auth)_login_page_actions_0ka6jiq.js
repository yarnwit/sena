module.exports=[1064,(a,b,c)=>{}];

//# sourceMappingURL=0qom_sena_frontend__next-internal_server_app_%28auth%29_login_page_actions_0ka6jiq.js.map