module.exports=[28408,(a,b,c)=>{}];

//# sourceMappingURL=0qom_sena_frontend__next-internal_server_app_admin_maintenance_page_actions_0kqnozt.js.map