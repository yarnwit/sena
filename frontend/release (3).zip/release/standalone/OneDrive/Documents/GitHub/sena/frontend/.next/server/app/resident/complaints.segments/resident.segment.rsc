1:"$Sreact.fragment"
2:I[86023,["/_next/static/chunks/2fm3gk9ef_80x.js","/_next/static/chunks/2dy2tjtop5e38.js","/_next/static/chunks/3bc93-2j7_8qn.js"],"ClientSegmentRoot"]
3:I[86372,["/_next/static/chunks/2fm3gk9ef_80x.js","/_next/static/chunks/2dy2tjtop5e38.js","/_next/static/chunks/3bc93-2j7_8qn.js","/_next/static/chunks/30brgxrjt7udd.js"],"default"]
4:I[72319,["/_next/static/chunks/2fm3gk9ef_80x.js","/_next/static/chunks/2dy2tjtop5e38.js","/_next/static/chunks/3bc93-2j7_8qn.js"],"default"]
5:I[61020,["/_next/static/chunks/2fm3gk9ef_80x.js","/_next/static/chunks/2dy2tjtop5e38.js","/_next/static/chunks/3bc93-2j7_8qn.js"],"default"]
0:{"rsc":["$","$1","c",{"children":[[["$","script","script-0",{"src":"/_next/static/chunks/30brgxrjt7udd.js","async":true}]],["$","$L2",null,{"Component":"$3","slots":{"children":["$","$L4",null,{"parallelRouterKey":"children","template":["$","$L5",null,{}]}]},"serverProvidedParams":{"params":{},"promises":["$@6"]}}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"nE37D1ivc-udvhVATSRFV"}
6:"$0:rsc:props:children:1:props:serverProvidedParams:params"
